const express = require('express');
const router = express.Router();
const User = require('../models/User');
const verifyToken = require('../middlewares/verifyToken');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

// Configuración de multer
const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: (_, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

/**
 * GET /users/:id - Ver perfil
 */
router.get('/:id', verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Error al obtener el usuario' });
  }
});

/**
 * PUT /users/:id - Editar perfil
 */
router.put('/:id', verifyToken, upload.single('fotoPerfil'), async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });

    if (req.file) {
      // Borrar la imagen anterior si existe
      if (user.fotoPerfil) {
        const rutaAnterior = path.join(__dirname, '../../uploads', user.fotoPerfil);
        if (fs.existsSync(rutaAnterior)) fs.unlinkSync(rutaAnterior);
      }
      user.fotoPerfil = req.file.filename;
    }

    if (req.body.nombre) user.nombre = req.body.nombre;
    if (req.body.email) user.email = req.body.email;

    await user.save();
    res.json({ message: 'Perfil actualizado', user });
  } catch (err) {
    res.status(500).json({ message: 'Error al actualizar el perfil' });
  }
});

/**
 * GET /users - Lista de usuarios
 */
router.get('/', verifyToken, async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: 'Error al obtener usuarios' });
  }
});

/**
 * GET /users/:id/foto - Ver foto de perfil (protegido)
 */
router.get('/:id/foto', verifyToken, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user || !user.fotoPerfil) {
      return res.status(404).json({ message: 'Foto no encontrada' });
    }

    const rutaFoto = path.join(__dirname, '../../uploads', user.fotoPerfil);
    if (!fs.existsSync(rutaFoto)) {
      return res.status(404).json({ message: 'Archivo no existe en el servidor' });
    }

    res.sendFile(rutaFoto);
  } catch (err) {
    res.status(500).json({ message: 'Error al obtener la foto' });
  }
});

router.put('/me', verifyToken, upload.single('fotoPerfil'), async (req, res) => {
  try {
    const updates = {
      nombre: req.body.nombre,
      email: req.body.email,
    };

    // Si subió nueva foto
    if (req.file) {
      updates.fotoPerfil = req.file.filename;
    }

    // Si quiere cambiar contraseña
    if (req.body.password) {
      const salt = await bcrypt.genSalt(10);
      updates.password = await bcrypt.hash(req.body.password, salt);
    }

    const updatedUser = await User.findByIdAndUpdate(req.userId, updates, { new: true });

    if (!updatedUser) {
      return res.status(404).json({ message: 'Usuario no encontrado' });
    }

    res.json({ message: 'Perfil actualizado', user: updatedUser });
  } catch (err) {
    res.status(500).json({ message: 'Error al actualizar perfil' });
  }
});


module.exports = router;
